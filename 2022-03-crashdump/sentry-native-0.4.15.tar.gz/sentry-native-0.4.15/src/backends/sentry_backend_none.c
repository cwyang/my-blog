#include "sentry_backend.h"

sentry_backend_t *
sentry__backend_new(void)
{
    return NULL;
}
